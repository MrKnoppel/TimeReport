using Crm.iOS.Services;
using Microsoft.Xrm.Sdk.Samples;
using System;
using UIKit;

namespace Crm.iOS
{
    partial class ProjectViewController : UITableViewController
	{
        public TimedActivitesService Service { get; set; }
        public Entity SelectedProject { get; set; }
		public ProjectViewController (IntPtr handle) : base (handle)
		{
		}
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            var tableSource = new TableSource(Service.ProjectList);
            tableSource.OnRowSelected += (object sender, TableSource.RowSelectedEventArgs e) => {
               
                e.tableView.DeselectRow(e.indexPath, true);
                SelectedProject = tableSource.SelectedItem;
                NavigationController.PopViewController(true);
            };
            tableViewProjects.Source = tableSource;
            tableViewProjects.ReloadData();
        }
        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
            if (OnClose != null)
            {
                OnClose(this, new OnCloseEventArgs());
            }
        }

        public event EventHandler<OnCloseEventArgs> OnClose;
        public class OnCloseEventArgs : EventArgs
        {
            public OnCloseEventArgs()
            {
            }
        }
    }
}
