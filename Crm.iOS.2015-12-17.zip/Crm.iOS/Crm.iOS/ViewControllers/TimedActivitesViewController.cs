using Foundation;
using System;
using UIKit;
using Crm.iOS.Services;
using Microsoft.Xrm.Sdk.Samples;
using CoreGraphics;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Crm.Sdk.Messages.Samples;
using Microsoft.Xrm.Sdk.Query.Samples;
using System.Threading.Tasks;
using System.Linq;

namespace Crm.iOS
{
    partial class TimedActivitesViewController : UITableViewController
	{
        private string commonAuthority = "https://login.windows.net/common";
        private string clientId = "35ee85a1-3a10-41dc-bef0-c9f32acddd0c";
        private Uri returnUri = new Uri("http://localhost/timereporting");
        private string serverUri = "https://siroccodev.crm4.dynamics.com"; // Dev 
        private AuthenticationResult authResult;
        AuthenticationContext authContext;
        TimedActivitesService service;
        private LoadingOverlay _loadPop;
        public Entity User { get; set; }
        public OrganizationDataWebServiceProxy Proxy { get; set; }

        public TimedActivitesViewController (IntPtr handle) : base (handle)
		{
        }
        async public override void ViewDidLoad()
        {
            await Authenticate();
            ShowLoadPop();
            base.ViewDidLoad();

            GetCrmConnection();
            await GetUser();
            service = new TimedActivitesService(User, Proxy);
            var tableSource = await service.GetTimedActivities();
            tableSource.OnRowSwiped += (object sender, TableSourceSimple.RowEventArgs e) =>
            {
                service.DeleteEntity(tableSource.SelectedItem);
            };

            tableViewTimedActivites.Source = tableSource;
            tableViewTimedActivites.ReloadData();
            _loadPop.Hide();
            service = new TimedActivitesService(User, Proxy);
            service.LoadEntitys();
        }
       
        public async Task GetUser()
        {
            WhoAmIResponse result = (WhoAmIResponse)await Proxy.Execute(new WhoAmIRequest());
            User = await Proxy.Retrieve("systemuser", result.UserId, new ColumnSet("fullname", "systemuserid"));
        }
        
        public async Task Authenticate()
        {
            authContext = new AuthenticationContext(commonAuthority);
            if (authContext.TokenCache.ReadItems().Count() > 0)
                authContext = new AuthenticationContext(authContext.TokenCache.ReadItems().First().Authority);
            authResult = await authContext.AcquireTokenAsync(serverUri, clientId, returnUri, new PlatformParameters(this));
        }
        public void GetCrmConnection()
        {
            Proxy = new OrganizationDataWebServiceProxy();
            Proxy.ServiceUrl = serverUri;
            Proxy.AccessToken = authResult.AccessToken;
        }        

        public override void PrepareForSegue(UIStoryboardSegue segue, NSObject sender)
        {
            base.PrepareForSegue(segue, sender);
            if (segue.Identifier.Equals("segueNewTimedActivity"))
            {
                var vc = segue.DestinationViewController as NewTimedActivityViewController;
                vc.Proxy = Proxy;
                vc.User = User;
                vc.Service = service;
                var source = tableViewTimedActivites.Source as TableSourceSimple;
                vc.TimedActivitiesCount = source.GetCellCount();
                
                vc.OnClose += async (object send, NewTimedActivityViewController.OnCloseEventArgs e) =>
                {
                    ShowLoadPop();
                    source = tableViewTimedActivites.Source as TableSourceSimple;
                     
                    while (vc.TimedActivitiesCount == source.GetCellCount()) // Checks if the list of Timed Activites has been updated, if not the it updateds
                    {
                        tableViewTimedActivites.Source = await service.GetTimedActivities();
                        source = tableViewTimedActivites.Source as TableSourceSimple;
                    }
                    tableViewTimedActivites.ReloadData();
                    _loadPop.Hide();
                };
            }
            if (segue.Identifier.Equals("segueDetails"))
            {
                var vc = segue.DestinationViewController as DetailsViewController;
                vc.Service = service;
                var source = tableViewTimedActivites.Source as TableSourceSimple;
                if (source != null)
                    vc.SelectedTimedActivity = source.GetItem(tableViewTimedActivites.IndexPathForSelectedRow.Row);
            }
        }               
        private void ShowLoadPop()
        {
            var bounds = UIScreen.MainScreen.Bounds;
            if (UIApplication.SharedApplication.StatusBarOrientation == UIInterfaceOrientation.LandscapeLeft || UIApplication.SharedApplication.StatusBarOrientation == UIInterfaceOrientation.LandscapeRight)
                bounds.Size = new CGSize(bounds.Size.Height, bounds.Size.Width);
            _loadPop = new LoadingOverlay(bounds);
            View.Add(_loadPop);
        }
        partial void btnLogout_Activated(UIBarButtonItem sender)
        {
            authContext.TokenCache.Clear();
            tableViewTimedActivites.Source = null;
            ViewDidLoad();
        }        
    }
}
