using Foundation;
using Microsoft.Xrm.Sdk.Samples;
using System;
using System.Collections.Generic;
using UIKit;
using Crm.iOS.Services;
using System.Linq;
using AudioToolbox;

namespace Crm.iOS
{
    partial class NewTimedActivityViewController : UITableViewController
	{
        public OrganizationDataWebServiceProxy Proxy { get; set; }
        public Entity User { get; set; }
        public TimedActivitesService Service { get; set; }
        Entity SelectedProject { get; set; }
        Entity SelectedPhase { get; set; }
        Entity SelectedTask { get; set; }
        Entity SelectedBilling { get; set; }        
        OptionSetValue SelectedLocation { get; set; }
        DateTime SelectedDate { get; set; }
        public int TimedActivitiesCount { get; set; }

        public NewTimedActivityViewController (IntPtr handle) : base (handle)
		{
        }
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            SetDefaultValues();            
        }

        private void SetDefaultValues()
        {
            //tbxDescription.BecomeFirstResponder();
            tbxDescription.Selected = true;
            SelectedDate = DateTime.Now; // Sets Todays date as Default
            lblSelectedDate.Text = string.Format("{0}-{1}-{2}", SelectedDate.Year, SelectedDate.Month, SelectedDate.Day);
            SelectedLocation = new OptionSetValue(4); // 4 = At Sirocco Office, Set as default.
            lblSelectedLocation.Text = "At Sirocco Office";
            tableCellPhase.Hidden = true;
            tableCellTask.Hidden = true;
            tableCellReson.Hidden = true;
            tableCellRemaningTime.Hidden = true;
            tableCellBilling.Hidden = true;

        }
        private Entity CollectInputData()
        {
            var nTA = new Entity("new_timedactivities");

            nTA.Attributes["new_name"] = tbxDescription.Text;
            nTA.Attributes["new_date"] = SelectedDate;
            nTA.Attributes["new_projectid"] = SelectedProject.ToEntityReference();
            if (tableCellPhase.Hidden == false)
                nTA.Attributes["custom_phase"] = SelectedPhase.ToEntityReference();
            if (tableCellTask.Hidden == false)
                nTA.Attributes["custom_projecttask_timedactivityid"] = SelectedTask.ToEntityReference();            
            nTA.Attributes["sirocco_billingid"] = SelectedBilling.ToEntityReference();
            nTA.Attributes["sirocco_location"] = SelectedLocation;
            nTA.Attributes["sirocco_actualtimehours"] = decimal.Parse(tbxActualTime.Text);
            nTA.Attributes["sirocco_billabletimehours"] = decimal.Parse(tbxBillableTime.Text);
            if (tbxReson.Hidden == false)
                nTA.Attributes["custom_reason"] = tbxReson.Text;
            if (tableCellRemaningTime.Hidden == false)
                nTA.Attributes["custom_remainingtimehours"] = decimal.Parse(tbxRemaningTime.Text);

            return nTA;
        }
        private void OnChange()
        {
            decimal bValue;
            decimal aValue;
            var b = tbxBillableTime.Text;
            var a = tbxActualTime.Text;
            if (Decimal.TryParse(a, out aValue) && Decimal.TryParse(b, out bValue))
            {
                if (aValue > bValue)
                    tableCellReson.Hidden = false;
                else if (aValue <= bValue)
                    tableCellReson.Hidden = true;
            }
            else
                tableCellReson.Hidden = true;
        }
        #region "Segues"
        //==========================================================================================================
        //================================================= SEGUES =================================================
        //==========================================================================================================

        /// <summary>
        /// This method runs when a TableCell is clicked in this Controllers TableView
        /// </summary>
        public override void PrepareForSegue(UIStoryboardSegue segue, NSObject sender)
        {
            if (segue.Identifier.Equals("segueDate"))
            {
                var vc = segue.DestinationViewController as DatePickerViewController;                
                vc.OnClose += (object send, DatePickerViewController.OnCloseEventArgs e) => {
                    ClearValidationColor();
                    SelectedDate = e.SelectedDate;
                    lblSelectedDate.Text = string.Format("{0}-{1}-{2}", SelectedDate.Year, SelectedDate.Month, SelectedDate.Day);
                };
            }            
            else if (segue.Identifier.Equals("segueProjects"))
            {
                var vc = segue.DestinationViewController as ProjectViewController;
                vc.Service = Service;
                vc.OnClose += (object send, ProjectViewController.OnCloseEventArgs e) => {
                    ClearValidationColor();
                    SelectedProject = vc.SelectedProject;
                    if (SelectedProject != null)
                    {
                        lblSelectedProject.Text = SelectedProject.Attributes["new_name"].ToString();                        
                        tableCellBilling.Hidden = false;
                        SelectedBilling = null;
                        tableCellRemaningTime.Hidden = true;
                        tableCellTask.Hidden = true;
                        tableCellTask.DetailTextLabel.Text = null;
                        
                        List<Entity> phaseList = Service.PhaseList.Select(p => p).Where(p => ((EntityReference)p.Attributes["custom_project"]).Id == SelectedProject.Id).ToList();
                        if (phaseList != null && phaseList.Count != 0)
                        {
                            tableCellPhase.Hidden = false;
                            tableCellPhase.DetailTextLabel.Text = null;
                        }
                        else
                            tableCellPhase.Hidden = true;
                    }
                };
            }
            else if (segue.Identifier.Equals("seguePhases"))
            {
                var vc = segue.DestinationViewController as PhaseViewController;
                vc.Service = Service;
                vc.SelectedProject = SelectedProject;
                vc.OnClose += (object send, PhaseViewController.OnCloseEventArgs e) => {
                    ClearValidationColor();
                    SelectedPhase = vc.SelectedPhase;
                    if (SelectedPhase != null)
                    {
                        lblSelectedPhase.Text = ((AliasedValue)SelectedPhase.Attributes["custom_name"]).Value.ToString();
                        tableCellRemaningTime.Hidden = true;

                        List<Entity> taskList = Service.TaskList.Select(p => p).Where(p => ((EntityReference)p.Attributes["custom_projectphase"]).Id == SelectedPhase.Id).ToList();
                        if (taskList != null && taskList.Count != 0) {
                            tableCellTask.Hidden = false;
                            tableCellTask.DetailTextLabel.Text = null;
                        }
                        else 
                            tableCellTask.Hidden = true;
                    }
                };
            }
            else if (segue.Identifier.Equals("segueTasks"))
            {
                var vc = segue.DestinationViewController as TaskViewController;
                vc.Service = Service;
                vc.SelectedPhase = SelectedPhase;
                vc.OnClose += (object send, TaskViewController.OnCloseEventArgs e) => {
                    ClearValidationColor();
                    SelectedTask = vc.SelectedTask;
                    if (SelectedTask != null)
                    {
                        lblSelectedTask.Text = ((AliasedValue)SelectedTask.Attributes["custom_name"]).Value.ToString();
                        tableCellRemaningTime.Hidden = false;
                    }
                };
            }
            else if (segue.Identifier.Equals("segueBilling"))
            {
                var vc = segue.DestinationViewController as BillingViewController;
                vc.Service = Service;
                vc.SelectedProject = SelectedProject;
                vc.OnClose += (object send, BillingViewController.OnCloseEventArgs e) => {
                    ClearValidationColor();
                    SelectedBilling = vc.SelectedBilling;
                    if (SelectedBilling != null)
                        lblSelectedBilling.Text = ((AliasedValue)SelectedBilling.Attributes["sirocco_description"]).Value.ToString();
                };
            }
            else if (segue.Identifier.Equals("segueLocation"))
            {
                var vc = segue.DestinationViewController as LocationViewController;
                vc.Service = Service;
                vc.OnClose += (object send, LocationViewController.OnCloseEventArgs e) => {
                    ClearValidationColor();
                    if (vc.SelectedLocation == "At Customer")
                        SelectedLocation.Value = 1;
                    else if (vc.SelectedLocation == "At Sirocco Office")
                        SelectedLocation.Value = 4;
                    else if (vc.SelectedLocation == "Conference Call")
                        SelectedLocation.Value = 2;
                    else if (vc.SelectedLocation == "Remote")
                        SelectedLocation.Value = 3;
                    if (vc.SelectedLocation != null)
                        lblSelectedLocation.Text = vc.SelectedLocation;
                };
            }
        }
        #endregion
        #region "Validations"
        //==========================================================================================================
        //=============================================== VALIDATIONS ===============================================
        //==========================================================================================================

        private void ClearValidationColor()
        {
            InvokeOnMainThread(() => {
                tbxActualTime.Layer.BorderColor = UIColor.Clear.CGColor;
                tbxBillableTime.Layer.BorderColor = UIColor.Clear.CGColor;
                tbxDescription.Layer.BorderColor = UIColor.Clear.CGColor;
                tbxRemaningTime.Layer.BorderColor = UIColor.Clear.CGColor;
                tbxReson.Layer.BorderColor = UIColor.Clear.CGColor;
                tableCellBilling.Layer.BorderColor = UIColor.Clear.CGColor;
                tableCellPhase.Layer.BorderColor = UIColor.Clear.CGColor;
                tableCellProject.Layer.BorderColor = UIColor.Clear.CGColor;
                tableCellTask.Layer.BorderColor = UIColor.Clear.CGColor;
            });
        }
        private bool ValidateAllFields()
        {
            bool v1 = false, v2 = false, v3 = false, v4 = false, v5 = false,
                v6 = false, v7 = false, v8 = false, v9 = false, v10 = false, v11 = false;
            List<bool> b = new List<bool>();

            v1 = ValidateTableCell(tableCellProject); b.Add(v1);            

            if (tableCellPhase.Hidden == false) {
                v2 = ValidateTableCell(tableCellPhase);
                b.Add(v2);
            }            
            if (tableCellTask.Hidden == false) {
                v3 = ValidateTableCell(tableCellTask);
                b.Add(v3);
            }            
            v4 = ValidateTableCell(tableCellBilling);
            b.Add(v4);            
            v5 = ValidateTableCell(tableCellLocation);
            b.Add(v5);
            v6 = ValidateTableCell(tableCellDate);
            b.Add(v6);
            v7 = ValidateTextInput(tbxDescription);
            b.Add(v7);
            v8 = ValidateNumberInput(tbxActualTime);
            b.Add(v8);
            v9 = ValidateNumberInput(tbxBillableTime);
            b.Add(v9);

            if (tableCellRemaningTime.Hidden == false) {
                v10 = ValidateNumberInput(tbxRemaningTime);
                b.Add(v10);
            }                   
            if (tableCellReson.Hidden == false) {
                v11 = ValidateTextInput(tbxReson);
                b.Add(v11);
            }
            if (b.All(x => x == true))
                return true;
            else return false;
        }        
        private bool ValidateTextInput(UITextField textField)
        {            
            if (textField.Text.Length <= 0) {
                InvokeOnMainThread(() => {
                    textField.Layer.BorderColor = UIColor.Red.CGColor;
                    textField.Layer.BorderWidth = 3;
                    textField.Layer.CornerRadius = 5;
                });
                return false;
            }
            else {
                InvokeOnMainThread(() => { 
                    textField.Layer.BorderColor = UIColor.Clear.CGColor;
                });
                return true;
            }
        }
        private bool ValidateNumberInput(UITextField textField)
        {
            decimal nr;
            if (decimal.TryParse(textField.Text, out nr))
            {
                InvokeOnMainThread(() => {
                    textField.Layer.BorderColor = UIColor.Clear.CGColor;
                });
                return true;               
            }           
            else {
                InvokeOnMainThread(() => {
                    textField.Layer.BorderColor = UIColor.Red.CGColor;
                    textField.Layer.BorderWidth = 3;
                    textField.Layer.CornerRadius = 5;
                });
                return false;
            }
        }
        private bool ValidateTableCell(UITableViewCell tableCell)
        {
            if (tableCell.DetailTextLabel.Text == null || tableCell.DetailTextLabel.Text == "") {
                InvokeOnMainThread(() => {
                    tableCell.Layer.BorderColor = UIColor.Red.CGColor;
                    tableCell.Layer.BorderWidth = 3;
                    tableCell.Layer.CornerRadius = 5;
                });
                return false;
            }
            else {
                InvokeOnMainThread(() => {
                    tableCell.Layer.BorderColor = UIColor.Clear.CGColor;
                });
                return true;
            }
        }
        #endregion
        #region "Events"
        //==========================================================================================================
        //================================================= EVENTS =================================================
        //==========================================================================================================
        partial void tbxDescription_DidEnd(UITextField sender)
        {
            ClearValidationColor();
        }
        partial void tbxRemaning_DidEnd(UITextField sender)
        {
            ClearValidationColor();
        }
        partial void tbxActualTime_OnChange(UITextField sender)
        {
            ClearValidationColor();
            OnChange();
        }
        partial void tbxBillableTime_OnChange(UITextField sender)
        {
            ClearValidationColor();
            OnChange();
        }
        partial void btnSave_Activated(UIBarButtonItem sender)
        {
            if (ValidateAllFields() == true)
            {
                var newTimedActivity = CollectInputData();
                Service.SaveTimedActivity(newTimedActivity);
                //new UIAlertView("Saved!", "Your Time report has been saved", null, "OK", null).Show();
                NavigationController.PopViewController(true);
                if (OnClose != null)
                    OnClose(this, new OnCloseEventArgs());
            }
            else
                SystemSound.Vibrate.PlaySystemSound();
        }
        public event EventHandler<OnCloseEventArgs> OnClose;
        public class OnCloseEventArgs : EventArgs
        {
            public OnCloseEventArgs()
            {
            }
        }
        #endregion
    }
}
