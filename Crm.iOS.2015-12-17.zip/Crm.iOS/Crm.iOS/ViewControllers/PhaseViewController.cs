using Crm.iOS.Services;
using Microsoft.Xrm.Sdk.Samples;
using System;
using System.Collections.Generic;
using System.Linq;
using UIKit;

namespace Crm.iOS
{
    partial class PhaseViewController : UITableViewController
	{
        public TimedActivitesService Service { get; set; }
        public Entity SelectedPhase { get; set; }
        public Entity SelectedProject { get; set; }
        public PhaseViewController (IntPtr handle) : base (handle)
		{
		}
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            var phaseList = GetPhaseList();
            var tableSource = new TableSource(phaseList);
            tableSource.OnRowSelected += (object sender, TableSource.RowSelectedEventArgs e) => {
                e.tableView.DeselectRow(e.indexPath, true);
                SelectedPhase = tableSource.SelectedItem;
                NavigationController.PopViewController(true);
            };
            tableViewPhases.Source = tableSource;
            tableViewPhases.ReloadData();
        }
        private List<Entity> GetPhaseList()
        {   
            if (SelectedProject == null)
                return null;
            List<Entity> phaseList = Service.PhaseList.Select(p => p).Where(p => ((EntityReference)p.Attributes["custom_project"]).Id == SelectedProject.Id).ToList();

            if (phaseList.Count != 0)
                return phaseList;
            else return null;
        }
        
        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
            if (OnClose != null)
            {
                OnClose(this, new OnCloseEventArgs());
            }
        }

        public event EventHandler<OnCloseEventArgs> OnClose;
        public class OnCloseEventArgs : EventArgs
        {
            public OnCloseEventArgs()
            {
            }
        }
    }
}
