using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;
using Microsoft.Xrm.Sdk.Samples;
using Crm.iOS.Services;

namespace Crm.iOS
{
	partial class DatePickerViewController : UIViewController
	{

        public DatePickerViewController (IntPtr handle) : base (handle)
		{
		}
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
        }
        partial void btnDone_Activated(UIBarButtonItem sender)
        {
            if (OnClose != null)
            {
                OnClose(this, new OnCloseEventArgs((DateTime)datePicker.Date));
            }
            NavigationController.PopViewController(true);
        }
        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);            
        }

        public event EventHandler<OnCloseEventArgs> OnClose;
        public class OnCloseEventArgs : EventArgs
        {
            public DateTime SelectedDate { get; set; }
            public OnCloseEventArgs(DateTime Date)
            {
                SelectedDate = Date;
            }
        }
    }
}
