using Crm.iOS.Services;
using Foundation;
using Microsoft.Xrm.Sdk.Samples;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace Crm.iOS
{
	partial class DetailsViewController : UITableViewController
	{
        public TimedActivitesService Service { get; set; }
       
        public Entity SelectedTimedActivity { get; set; }
		public DetailsViewController (IntPtr handle) : base (handle)
		{
		}
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            if (SelectedTimedActivity != null)
            {
                Title = SelectedTimedActivity.Attributes["new_name"].ToString();
                lblDescription.Text = SelectedTimedActivity.Attributes["new_name"].ToString();

                DateTime date = (DateTime)SelectedTimedActivity.Attributes["new_date"];
                lblDate.Text = string.Format("{0}-{1}-{2}", date.Year, date.Month, date.Day);

                lblProject.Text = SelectedTimedActivity.Contains("new_projectid") ?
                    ((EntityReference)SelectedTimedActivity.Attributes["new_projectid"]).Name : "*Empty*";

                lblPhase.Text = SelectedTimedActivity.Contains("custom_phase") ?
                    ((EntityReference)SelectedTimedActivity.Attributes["custom_phase"]).Name : "*Empty*";

                lblTask.Text = SelectedTimedActivity.Contains("custom_projecttask_timedactivityid") ?
                    ((EntityReference)SelectedTimedActivity.Attributes["custom_projecttask_timedactivityid"]).Name : "*Empty*";

                lblBilling.Text = SelectedTimedActivity.Contains("sirocco_billingid") ?
                    ((EntityReference)SelectedTimedActivity.Attributes["sirocco_billingid"]).Name : "*Empty*";

                if (SelectedTimedActivity.Contains("sirocco_location"))
                {
                    var i = ((OptionSetValue)SelectedTimedActivity.Attributes["sirocco_location"]).Value;
                    lblLocation.Text = Service.LocationList[--i];
                }
                else lblLocation.Text = "*Empty*";
                if (SelectedTimedActivity.Contains("sirocco_actualtimehours"))
                {
                    var a = (decimal)SelectedTimedActivity.Attributes["sirocco_actualtimehours"];
                    lblActualTime.Text = string.Format("{0} hours", Math.Round(a));
                }
                else lblActualTime.Text = "*Empty*";
                if (SelectedTimedActivity.Contains("sirocco_billabletimehours"))
                {
                    var b = (decimal)SelectedTimedActivity.Attributes["sirocco_billabletimehours"];
                    lblBillableTime.Text = string.Format("{0} hours", Math.Round(b));
                }
                else lblBillableTime.Text = "*Empty*";

                lblReason.Text = SelectedTimedActivity.Contains("custom_reason") ?
                    SelectedTimedActivity.Attributes["custom_reason"].ToString() : "*Empty*";

                if (SelectedTimedActivity.Contains("custom_remainingtimehours"))
                {
                    var r = (decimal)SelectedTimedActivity.Attributes["custom_remainingtimehours"];
                    lblRemaningTime.Text = string.Format("{0} hours", Math.Round(r));
                }
                else lblRemaningTime.Text = "*Empty*";
            }
        }
    }
}
