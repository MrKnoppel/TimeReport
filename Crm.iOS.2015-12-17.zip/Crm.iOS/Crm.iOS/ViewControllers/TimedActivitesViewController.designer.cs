// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace Crm.iOS
{
	[Register ("TimedActivitesViewController")]
	partial class TimedActivitesViewController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIBarButtonItem btnAdd { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIBarButtonItem btnLogout { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableView tableViewTimedActivites { get; set; }

		[Action ("btnAdd_Activated:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void btnAdd_Activated (UIBarButtonItem sender);

		[Action ("btnLogout_Activated:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void btnLogout_Activated (UIBarButtonItem sender);

		void ReleaseDesignerOutlets ()
		{
			if (btnAdd != null) {
				btnAdd.Dispose ();
				btnAdd = null;
			}
			if (btnLogout != null) {
				btnLogout.Dispose ();
				btnLogout = null;
			}
			if (tableViewTimedActivites != null) {
				tableViewTimedActivites.Dispose ();
				tableViewTimedActivites = null;
			}
		}
	}
}
