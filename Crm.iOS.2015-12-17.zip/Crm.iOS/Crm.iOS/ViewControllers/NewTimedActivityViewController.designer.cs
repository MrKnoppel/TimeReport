// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace Crm.iOS
{
	[Register ("NewTimedActivityViewController")]
	partial class NewTimedActivityViewController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIBarButtonItem btnSave { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblSelectedBilling { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblSelectedDate { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblSelectedLocation { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblSelectedPhase { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblSelectedProject { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblSelectedTask { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellActualTime { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellBillableTime { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellBilling { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellDate { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellLocation { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellPhase { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellProject { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellRemaningTime { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellReson { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableViewCell tableCellTask { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableView tableViewNewTimedActivites { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITextField tbxActualTime { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITextField tbxBillableTime { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITextField tbxDescription { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITextField tbxRemaningTime { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITextField tbxReson { get; set; }

		[Action ("btnSave_Activated:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void btnSave_Activated (UIBarButtonItem sender);

		[Action ("tbxActualTime_OnChange:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void tbxActualTime_OnChange (UITextField sender);

		[Action ("tbxBillableTime_OnChange:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void tbxBillableTime_OnChange (UITextField sender);

		[Action ("tbxDescription_DidEnd:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void tbxDescription_DidEnd (UITextField sender);

		[Action ("tbxRemaning_DidEnd:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void tbxRemaning_DidEnd (UITextField sender);

		void ReleaseDesignerOutlets ()
		{
			if (btnSave != null) {
				btnSave.Dispose ();
				btnSave = null;
			}
			if (lblSelectedBilling != null) {
				lblSelectedBilling.Dispose ();
				lblSelectedBilling = null;
			}
			if (lblSelectedDate != null) {
				lblSelectedDate.Dispose ();
				lblSelectedDate = null;
			}
			if (lblSelectedLocation != null) {
				lblSelectedLocation.Dispose ();
				lblSelectedLocation = null;
			}
			if (lblSelectedPhase != null) {
				lblSelectedPhase.Dispose ();
				lblSelectedPhase = null;
			}
			if (lblSelectedProject != null) {
				lblSelectedProject.Dispose ();
				lblSelectedProject = null;
			}
			if (lblSelectedTask != null) {
				lblSelectedTask.Dispose ();
				lblSelectedTask = null;
			}
			if (tableCellActualTime != null) {
				tableCellActualTime.Dispose ();
				tableCellActualTime = null;
			}
			if (tableCellBillableTime != null) {
				tableCellBillableTime.Dispose ();
				tableCellBillableTime = null;
			}
			if (tableCellBilling != null) {
				tableCellBilling.Dispose ();
				tableCellBilling = null;
			}
			if (tableCellDate != null) {
				tableCellDate.Dispose ();
				tableCellDate = null;
			}
			if (tableCellLocation != null) {
				tableCellLocation.Dispose ();
				tableCellLocation = null;
			}
			if (tableCellPhase != null) {
				tableCellPhase.Dispose ();
				tableCellPhase = null;
			}
			if (tableCellProject != null) {
				tableCellProject.Dispose ();
				tableCellProject = null;
			}
			if (tableCellRemaningTime != null) {
				tableCellRemaningTime.Dispose ();
				tableCellRemaningTime = null;
			}
			if (tableCellReson != null) {
				tableCellReson.Dispose ();
				tableCellReson = null;
			}
			if (tableCellTask != null) {
				tableCellTask.Dispose ();
				tableCellTask = null;
			}
			if (tableViewNewTimedActivites != null) {
				tableViewNewTimedActivites.Dispose ();
				tableViewNewTimedActivites = null;
			}
			if (tbxActualTime != null) {
				tbxActualTime.Dispose ();
				tbxActualTime = null;
			}
			if (tbxBillableTime != null) {
				tbxBillableTime.Dispose ();
				tbxBillableTime = null;
			}
			if (tbxDescription != null) {
				tbxDescription.Dispose ();
				tbxDescription = null;
			}
			if (tbxRemaningTime != null) {
				tbxRemaningTime.Dispose ();
				tbxRemaningTime = null;
			}
			if (tbxReson != null) {
				tbxReson.Dispose ();
				tbxReson = null;
			}
		}
	}
}
