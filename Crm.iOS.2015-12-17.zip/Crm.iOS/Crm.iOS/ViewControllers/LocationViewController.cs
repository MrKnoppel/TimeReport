using Crm.iOS.Services;
using Microsoft.Xrm.Sdk.Samples;
using System;
using UIKit;

namespace Crm.iOS
{
    partial class LocationViewController : UITableViewController
	{
        public TimedActivitesService Service { get; set; }
        public string SelectedLocation { get; set; }
        public LocationViewController (IntPtr handle) : base (handle)
		{
		}
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            var tableSource = new TableSourceString(Service.LocationList);
            tableSource.OnRowSelected += (object sender, TableSourceString.RowSelectedEventArgs e) => {
                e.tableView.DeselectRow(e.indexPath, true);
                SelectedLocation = tableSource.SelectedItem;
                NavigationController.PopViewController(true);
            };
            tableViewLocation.Source = tableSource;
            tableViewLocation.ReloadData();
        }
        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
            if (OnClose != null)
            {
                OnClose(this, new OnCloseEventArgs());
            }
        }

        public event EventHandler<OnCloseEventArgs> OnClose;
        public class OnCloseEventArgs : EventArgs
        {
            public OnCloseEventArgs()
            {
            }
        }
    }
}
