using Crm.iOS.Services;
using Microsoft.Xrm.Sdk.Samples;
using System;
using System.Collections.Generic;
using System.Linq;
using UIKit;

namespace Crm.iOS
{
    partial class TaskViewController : UITableViewController
	{
        public TimedActivitesService Service { get; set; }
        public Entity SelectedTask { get; set; }
        public Entity SelectedPhase { get; set; }
        public TaskViewController (IntPtr handle) : base (handle)
		{
		}
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            var taskList = GetTaskList();
            var tableSource = new TableSource(taskList);
            tableSource.OnRowSelected += (object sender, TableSource.RowSelectedEventArgs e) => {
                e.tableView.DeselectRow(e.indexPath, true);
                SelectedTask = tableSource.SelectedItem;
                NavigationController.PopViewController(true);
            };
            tableViewTasks.Source = tableSource;
            tableViewTasks.ReloadData();
        }

        private List<Entity> GetTaskList()
        {
            if (SelectedPhase == null)
                return null;
            List<Entity> taskList = Service.TaskList.Select(p => p).Where
                (p => ((EntityReference)p.Attributes["custom_projectphase"]).Id == SelectedPhase.Id).ToList();

            if (taskList.Count != 0)
                return taskList;
            else return null;
        }
        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
            if (OnClose != null)
            {
                OnClose(this, new OnCloseEventArgs());
            }
        }

        public event EventHandler<OnCloseEventArgs> OnClose;
        public class OnCloseEventArgs : EventArgs
        {
            public OnCloseEventArgs()
            {
            }
        }
    }
}
