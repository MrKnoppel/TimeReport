using Crm.iOS.Services;
using Microsoft.Xrm.Sdk.Samples;
using System;
using System.Collections.Generic;
using System.Linq;
using UIKit;

namespace Crm.iOS
{
    partial class BillingViewController : UITableViewController
	{

        public TimedActivitesService Service { get; set; }  
        public Entity SelectedBilling { get; set; }
        public Entity SelectedProject { get; set; }
        public BillingViewController (IntPtr handle) : base (handle)
		{
		}
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            var billingList = GetBillingList();
            var tableSource = new TableSource(billingList);
            tableSource.OnRowSelected += (object sender, TableSource.RowSelectedEventArgs e) => {
                e.tableView.DeselectRow(e.indexPath, true);
                SelectedBilling = tableSource.SelectedItem;
                NavigationController.PopViewController(true);
            };
            tableViewBilling.Source = tableSource;
            tableViewBilling.ReloadData();
        }

        private List<Entity> GetBillingList()
        {
            if (SelectedProject == null)
                return null;
            List<Entity> billingList = Service.BillingList.Select(p => p).Where
                (p => ((EntityReference)p.Attributes["sirocco_project"]).Id == SelectedProject.Id).ToList();

            if (billingList.Count != 0)
                return billingList;
            else return Service.BillingList;
        }

        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
            if (OnClose != null)
            {
                OnClose(this, new OnCloseEventArgs());
            }
        }

        public event EventHandler<OnCloseEventArgs> OnClose;
        public class OnCloseEventArgs : EventArgs
        {
            public OnCloseEventArgs()
            {
            }
        }
    }
}
