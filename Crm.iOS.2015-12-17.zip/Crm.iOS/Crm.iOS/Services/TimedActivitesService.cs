﻿using Microsoft.Xrm.Sdk.Query.Samples;
using Microsoft.Xrm.Sdk.Samples;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace Crm.iOS.Services
{
    public class TimedActivitesService
    {
        private OrganizationDataWebServiceProxy proxy;
        private Entity user;

        public List<Entity> ProjectList = new List<Entity>();
        public List<Entity> PhaseList = new List<Entity>();
        public List<Entity> TaskList = new List<Entity>();
        public List<Entity> BillingList = new List<Entity>();
        public List<Entity> TimedActivitiesList = new List<Entity>();
        public List<string> LocationList = new List<string>() { "At Customer", "Conference Call", "Remote", "At Sirocco Office" };
        
        public TimedActivitesService(Entity user, OrganizationDataWebServiceProxy proxy)
        {
            this.user = user;
            this.proxy = proxy;
        }
        public async Task<TableSourceSimple> GetTimedActivities()
        {
            var query = new QueryExpression("new_timedactivities");
            query.ColumnSet = new ColumnSet(true);

            // Skapar villkor för vilka TimedActivites som ska hanteras
            var memberCondition = new ConditionExpression("ownerid", ConditionOperator.Equal, user.Id);
            var taMemberFilter = new FilterExpression(LogicalOperator.And);
            taMemberFilter.AddCondition(memberCondition);
            query.Criteria.AddFilter(taMemberFilter);

            EntityCollection result = await proxy.RetrieveMultiple(query);

            List<Entity> TableItems = new List<Entity>();
            foreach (Entity item in result.Entities)
            {
                var tableItem = new Entity();
                tableItem = item;
                TableItems.Add(tableItem);
            }
            return new TableSourceSimple(TableItems);
        }
        public async void LoadEntitys()
        {
            var list = await GetProjects();
            ManageCrmEntitys(list);
        }
        public async void DeleteEntity(Entity entity)
        {
            try
            {
                await proxy.Delete(entity.LogicalName, entity.Id);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public async void SaveTimedActivity(Entity newTimedActivity)
        {
            try
            {
            await proxy.Create(newTimedActivity);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }
        private async Task<EntityCollection> GetProjects()
        {
            var query = new QueryExpression("new_project");
            query.ColumnSet = new ColumnSet("new_name");
            var projectMemberFilter = new FilterExpression(LogicalOperator.And);
            var memberCondition = new ConditionExpression("Projectmember", "custom_user", ConditionOperator.Equal, user.Id);
            projectMemberFilter.AddCondition(memberCondition);
            query.Criteria.AddFilter(projectMemberFilter);
            LinkEntities(query);

            var listOfProjects = await proxy.RetrieveMultiple(query);
            return listOfProjects.Entities.Any() ? listOfProjects : null;
        }
        private void ManageCrmEntitys(EntityCollection listOfProjects)
        {
            foreach (Entity project in listOfProjects.Entities)
            {
                if (ProjectList.Select(p => p).Where(p => p.Id == project.Id).Count() <= 0)
                {
                    var newProject = new Entity("new_project");
                    newProject.Id = project.Id;
                    newProject.Attributes["new_name"] = project["new_name"];
                    
                    ProjectList.Add(newProject);
                }

                //Om Project innehåller Phase, fyll på PhaseList med Phase
                if (project.Attributes.Contains("ProjectPhases.custom_name"))
                {
                    if (PhaseList.Select(p => p).Where(p => (Guid)((AliasedValue)p.Attributes["custom_projectphaseid"]).Value == (Guid)((AliasedValue)project["ProjectPhases.custom_projectphaseid"]).Value).Count() <= 0)
                    {
                        var newPhase = new Entity();
                        newPhase.Attributes["custom_project"] = project.ToEntityReference();
                        newPhase.Attributes["custom_projectphaseid"] = project["ProjectPhases.custom_projectphaseid"];
                        newPhase.Id = (Guid)((AliasedValue)project.Attributes["ProjectPhases.custom_projectphaseid"]).Value;
                        newPhase.Attributes["custom_name"] = project["ProjectPhases.custom_name"];
                        PhaseList.Add(newPhase);
                    }
                }
                // Om Phase innehåller Task, fyll på TaskList med Task
                if (project.Attributes.Contains("PhaseTasks.custom_name"))
                {
                    if (TaskList.Select(t => t).Where(t => (Guid)((AliasedValue)t.Attributes["custom_projecttaskid"]).Value == (Guid)((AliasedValue)project["PhaseTasks.custom_projecttaskid"]).Value).Count() <= 0)
                    {
                        EntityReference refPhase = null;
                        if (project.Attributes.Contains("PhaseTasks.custom_projectphase"))
                            refPhase = (EntityReference)((AliasedValue)project["PhaseTasks.custom_projectphase"]).Value;

                        var newTask = new Entity();
                        newTask.Attributes["custom_project"] = project.ToEntityReference();
                        newTask.Attributes["custom_projectphase"] = refPhase;
                        newTask.Attributes["custom_projecttaskid"] = project["PhaseTasks.custom_projecttaskid"];
                        newTask.Id = (Guid)((AliasedValue)project.Attributes["PhaseTasks.custom_projecttaskid"]).Value;
                        newTask.Attributes["custom_name"] = project["PhaseTasks.custom_name"];
                        TaskList.Add(newTask);
                    }
                }

                //Fyller på BillingList
                if (project.Attributes.Contains("ProjectBillings.sirocco_description"))
                {
                    if (BillingList.Select(b => b).Where(b => (Guid)((AliasedValue)b.Attributes["sirocco_projectbillingid"]).Value == (Guid)((AliasedValue)project["ProjectBillings.sirocco_projectbillingid"]).Value).Count() <= 0)
                    {
                        var newBilling = new Entity();
                        newBilling.Attributes["sirocco_description"] = project["ProjectBillings.sirocco_description"];
                        newBilling.Attributes["sirocco_projectbillingid"] = project["ProjectBillings.sirocco_projectbillingid"];
                        newBilling.Id = (Guid)((AliasedValue)project.Attributes["ProjectBillings.sirocco_projectbillingid"]).Value;
                        newBilling.Attributes["sirocco_project"] = project.ToEntityReference();
                        BillingList.Add(newBilling);
                    }
                }
            }
        }
        private void LinkEntities(QueryExpression projectQuery)
        {
            // Länkar alla projekt där userid är med
            var memberlink = new LinkEntity()
            {
                LinkFromEntityName = "new_project",
                LinkToEntityName = "custom_projectmember",
                LinkFromAttributeName = "new_projectid",
                LinkToAttributeName = "custom_project",
                JoinOperator = JoinOperator.Inner
            };
            projectQuery.LinkEntities.Add(memberlink);
            projectQuery.LinkEntities[0].EntityAlias = "Projectmember";

            // Länkar alla Phase som finns med i Project
            var phaselink = new LinkEntity()
            {
                LinkFromEntityName = "new_project",
                LinkToEntityName = "custom_projectphase",
                LinkFromAttributeName = "new_projectid",
                LinkToAttributeName = "custom_project",
                JoinOperator = JoinOperator.Inner
            };
            projectQuery.LinkEntities.Add(phaselink);
            projectQuery.LinkEntities[1].EntityAlias = "ProjectPhases";
            projectQuery.LinkEntities[1].Columns.AddColumns("custom_name", "custom_projectphaseid", "custom_project");

            // Länkar alla Task som finns med i Phase
            var tasklink = new LinkEntity()
            {
                LinkFromEntityName = "new_project",
                LinkToEntityName = "custom_projecttask",
                LinkFromAttributeName = "new_projectid",
                LinkToAttributeName = "custom_project",
                JoinOperator = JoinOperator.LeftOuter
            };
            projectQuery.LinkEntities.Add(tasklink);
            projectQuery.LinkEntities[2].EntityAlias = "PhaseTasks";
            projectQuery.LinkEntities[2].Columns.AddColumns("custom_name", "custom_projecttaskid", "custom_projectphase", "custom_project");

            // Länkar alla Billing som finns med i Project
            var billinglink = new LinkEntity()
            {
                LinkFromEntityName = "new_project",
                LinkToEntityName = "sirocco_projectbilling",
                LinkFromAttributeName = "new_projectid",
                LinkToAttributeName = "sirocco_project",
                JoinOperator = JoinOperator.LeftOuter
            };
            projectQuery.LinkEntities.Add(billinglink);
            projectQuery.LinkEntities[3].EntityAlias = "ProjectBillings";
            projectQuery.LinkEntities[3].Columns.AddColumns("sirocco_description", "sirocco_projectbillingid", "sirocco_project");
        }        
    }
}
