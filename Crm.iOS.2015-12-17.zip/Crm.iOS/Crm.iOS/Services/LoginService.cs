﻿using Microsoft.Crm.Sdk.Messages.Samples;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Xrm.Sdk.Query.Samples;
using Microsoft.Xrm.Sdk.Samples;
using System;
using System.Linq;
using System.Threading.Tasks;
using UIKit;

namespace Crm.iOS.Services
{
    public class LoginService
    {
        // Denna klass används inte just nu
        private string commonAuthority = "https://login.windows.net/common";
        private string clientId = "35ee85a1-3a10-41dc-bef0-c9f32acddd0c";
        private Uri returnUri = new Uri("http://localhost/timereporting");
        private string serverUri = "https://siroccodev.crm4.dynamics.com";
        private AuthenticationResult authResult;

        public Entity user;
        public OrganizationDataWebServiceProxy proxy;
        public LoginService()
        {

        }
        public async Task Authenticate(UIViewController controller)
        {
            AuthenticationContext authContext = new AuthenticationContext(commonAuthority);
            if (authContext.TokenCache.ReadItems().Count() > 0)
                authContext = new AuthenticationContext(authContext.TokenCache.ReadItems().First().Authority);
           
            authResult = await authContext.AcquireTokenAsync(serverUri, clientId, returnUri, new PlatformParameters(controller));
        }
        public void GetCrmConnection()
        {
            proxy = new OrganizationDataWebServiceProxy();
            proxy.ServiceUrl = serverUri;
            proxy.AccessToken = authResult.AccessToken;
        }
        public async Task GetUser()
        {
            WhoAmIResponse result = (WhoAmIResponse)await proxy.Execute(new WhoAmIRequest());
            user = await proxy.Retrieve("systemuser", result.UserId, new ColumnSet("fullname", "systemuserid"));
        }

    }
}
