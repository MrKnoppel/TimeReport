// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace Crm.iOS
{
	[Register ("DetailsViewController")]
	partial class DetailsViewController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblActualTime { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblBillableTime { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblBilling { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblDate { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblDescription { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblLocation { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblPhase { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblProject { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblReason { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblRemaningTime { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UILabel lblTask { get; set; }

		void ReleaseDesignerOutlets ()
		{
			if (lblActualTime != null) {
				lblActualTime.Dispose ();
				lblActualTime = null;
			}
			if (lblBillableTime != null) {
				lblBillableTime.Dispose ();
				lblBillableTime = null;
			}
			if (lblBilling != null) {
				lblBilling.Dispose ();
				lblBilling = null;
			}
			if (lblDate != null) {
				lblDate.Dispose ();
				lblDate = null;
			}
			if (lblDescription != null) {
				lblDescription.Dispose ();
				lblDescription = null;
			}
			if (lblLocation != null) {
				lblLocation.Dispose ();
				lblLocation = null;
			}
			if (lblPhase != null) {
				lblPhase.Dispose ();
				lblPhase = null;
			}
			if (lblProject != null) {
				lblProject.Dispose ();
				lblProject = null;
			}
			if (lblReason != null) {
				lblReason.Dispose ();
				lblReason = null;
			}
			if (lblRemaningTime != null) {
				lblRemaningTime.Dispose ();
				lblRemaningTime = null;
			}
			if (lblTask != null) {
				lblTask.Dispose ();
				lblTask = null;
			}
		}
	}
}
