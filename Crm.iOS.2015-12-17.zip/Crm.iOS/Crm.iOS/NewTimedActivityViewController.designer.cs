// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace Crm.iOS
{
	[Register ("NewTimedActivityViewController")]
	partial class NewTimedActivityViewController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton btnSave { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableView tableViewNewTimedActivites { get; set; }

		[Action ("btnSaveTouchInside:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void btnSaveTouchInside (UIButton sender);

		[Action ("btnSaveUpInside:")]
		[GeneratedCode ("iOS Designer", "1.0")]
		partial void btnSaveUpInside (UIButton sender);

		void ReleaseDesignerOutlets ()
		{
			if (btnSave != null) {
				btnSave.Dispose ();
				btnSave = null;
			}
			if (tableViewNewTimedActivites != null) {
				tableViewNewTimedActivites.Dispose ();
				tableViewNewTimedActivites = null;
			}
		}
	}
}
