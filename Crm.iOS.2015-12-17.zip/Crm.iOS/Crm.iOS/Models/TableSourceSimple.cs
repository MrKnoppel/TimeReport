﻿using System;
using System.Collections.Generic;
using Foundation;
using UIKit;
using System.Linq;
using Microsoft.Xrm.Sdk.Samples;
using Crm.iOS.Services;
using System.Threading.Tasks;

namespace Crm.iOS
{
    public class TableSourceSimple : UITableViewSource
    {
        string cellIdentifier = "TableCell";
        public List<Entity> TableItems { get; set; }
        public Entity SelectedItem { get; private set; }
        public UIAlertController deleteAlertController;
        public TableSourceSimple(List<Entity> TableItems)
        {
            this.TableItems = TableItems.OrderByDescending(x => x.Attributes["new_date"]).ThenByDescending(x => x.Attributes["new_name"]).ToList();
            
            deleteAlertController = UIAlertController.Create("Delete", "Continue with Delete? ", UIAlertControllerStyle.ActionSheet);
            deleteAlertController.AddAction(UIAlertAction.Create("Okay", UIAlertActionStyle.Default, (action) => Console.WriteLine("Okay was clicked")));
            deleteAlertController.AddAction(UIAlertAction.Create("Cancel", UIAlertActionStyle.Cancel, (action) => Console.WriteLine("Cancel was clicked")));
        }
        public override async void CommitEditingStyle(UITableView tableView, UITableViewCellEditingStyle editingStyle, NSIndexPath indexPath)
        {
            switch (editingStyle)
            {
                case UITableViewCellEditingStyle.Delete:
                    SelectedItem = GetItem(indexPath.Row);
                    nint button = await ShowAlert("Are you sure", "Delete?", "Yes", "Cancel");
                    if (button == 0)
                    {
                        if (OnRowSwiped != null)
                        {
                            OnRowSwiped(this, new RowEventArgs(tableView, indexPath));
                        }
                        TableItems.RemoveAt(indexPath.Row);
                        tableView.DeleteRows(new NSIndexPath[] { indexPath }, UITableViewRowAnimation.Fade);
                        Console.WriteLine("Row {0} Deleted", indexPath.Row + 1);
                    }
                    else
                        tableView.Editing = false;
                    break;

                case UITableViewCellEditingStyle.None:
                    Console.WriteLine("CommitEditingStyle:None called");
                    break;
            }
        }
        // Displays a UIAlertView and returns the index of the button pressed.
        public static Task<nint> ShowAlert(string title, string message, params string[] buttons)
        {
            var tcs = new TaskCompletionSource<nint>();
            var alert = new UIAlertView
            {
                Title = title,
                Message = message
            };
            foreach (var button in buttons)
                alert.AddButton(button);
            alert.Clicked += (s, e) => tcs.TrySetResult(e.ButtonIndex);
            alert.Show();
            return tcs.Task;
        }
        public override bool CanEditRow(UITableView tableView, NSIndexPath indexPath)
        {
            return true; // return false if you wish to disable editing for a specific indexPath or for all rows
        }

        public Entity GetItem(int index)
        {
            return TableItems[index];
        }
        public int GetCellCount()
        {
            return TableItems.Count;
        }
        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            UITableViewCell cell = tableView.DequeueReusableCell(cellIdentifier);
            Entity item = TableItems[indexPath.Row];
            
            if (cell == null)
                cell = new UITableViewCell(UITableViewCellStyle.Subtitle, cellIdentifier);
            var project = ((EntityReference)item.Attributes["new_projectid"]).Name;
            var actualTime = (decimal)item.Attributes["sirocco_actualtimehours"];
            var date = (DateTime)item.Attributes["new_date"];

            if (string.IsNullOrEmpty(project))
                project = "Unknown";

            cell.TextLabel.Text = project;
            cell.DetailTextLabel.Text = string.Format("{0}-{1}-{2} ({3} hours)", date.Year, date.Month, date.Day, Math.Round(actualTime));
            return cell;
        }
        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return TableItems.Count;
        }
       
        public event EventHandler<RowEventArgs> OnRowSwiped;
        public class RowEventArgs : EventArgs
        {
            public UITableView tableView { get; set; }
            public NSIndexPath indexPath { get; set; }

            public RowEventArgs(UITableView tableView, NSIndexPath indexPath) : base()
            {
                this.tableView = tableView;
                this.indexPath = indexPath;
            }
        }
    }
}
