﻿using System;
using System.Collections.Generic;
using Foundation;
using UIKit;

namespace Crm.iOS
{
    public class TableSourceString : UITableViewSource
    {
        public event EventHandler<RowSelectedEventArgs> OnRowSelected;
        string cellIdentifier = "TableCell";
        public List<string> TableItems { get; set; }
        public string SelectedItem { get; set; }
        public TableSourceString(List<string> TableItems)
        {
            this.TableItems = TableItems;
        }
        public string GetItem(int index)
        {   
            return TableItems[index];
        }       
        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {
            SelectedItem = GetItem(indexPath.Row);
            if (OnRowSelected != null)
            {
                OnRowSelected(this, new RowSelectedEventArgs(tableView, indexPath));
            }
        }
        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return TableItems.Count;
        }
        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            UITableViewCell cell = tableView.DequeueReusableCell(cellIdentifier);
            if (cell == null)
                cell = new UITableViewCell(UITableViewCellStyle.Default, cellIdentifier);
            string name = "";
            name = TableItems[indexPath.Row];
            if (string.IsNullOrEmpty(name))
                name = "Unknown";

            cell.TextLabel.Text = name;
            return cell;
        }
        public class RowSelectedEventArgs : EventArgs
        {
            public UITableView tableView { get; set; }
            public NSIndexPath indexPath { get; set; }

            public RowSelectedEventArgs(UITableView tableView, NSIndexPath indexPath) : base()
            {
                this.tableView = tableView;
                this.indexPath = indexPath;
            }
        }
    }
}
