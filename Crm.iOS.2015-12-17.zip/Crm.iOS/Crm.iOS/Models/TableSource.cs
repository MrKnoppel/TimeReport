﻿using System;
using System.Collections.Generic;
using Foundation;
using Microsoft.Xrm.Sdk.Samples;
using UIKit;

namespace Crm.iOS
{
    public class TableSource : UITableViewSource
    {
        public event EventHandler<RowSelectedEventArgs> OnRowSelected;
        string cellIdentifier = "TableCell";
        public List<Entity> TableItems { get; set; }
        public Entity SelectedItem { get; set; }
        public TableSource(List<Entity> TableItems)
        {
            this.TableItems = TableItems;
        }
        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {
            SelectedItem = GetItem(indexPath.Row);
            if (OnRowSelected != null)
            {
                OnRowSelected(this, new RowSelectedEventArgs(tableView, indexPath));
            }
        }
        
        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return TableItems.Count;
        }
        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            UITableViewCell cell = tableView.DequeueReusableCell(cellIdentifier);
            if (cell == null)
                cell = new UITableViewCell(UITableViewCellStyle.Default, cellIdentifier);
            string name = "";
            if (TableItems[indexPath.Row].Attributes.Contains("new_name"))
                name = TableItems[indexPath.Row].Attributes["new_name"].ToString();
            else if (TableItems[indexPath.Row].Attributes.Contains("custom_name"))
                name = ((AliasedValue)TableItems[indexPath.Row].Attributes["custom_name"]).Value.ToString();
            else if(TableItems[indexPath.Row].Attributes.Contains("sirocco_description"))
                name = ((AliasedValue)TableItems[indexPath.Row].Attributes["sirocco_description"]).Value.ToString();
            if (string.IsNullOrEmpty(name))
                name = "Unknown";

            cell.TextLabel.Text = name;
            return cell;
        }

        public Entity GetItem(int index)
        {
            return TableItems[index];
        }
        
        public class RowSelectedEventArgs : EventArgs
        {
            public UITableView tableView { get; set; }
            public NSIndexPath indexPath { get; set; }

            public RowSelectedEventArgs(UITableView tableView, NSIndexPath indexPath) : base()
            {
                this.tableView = tableView;
                this.indexPath = indexPath;
            }
        }        
    }
}