// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace Crm.iOS
{
	[Register ("TimeReportViewController")]
	partial class TimeReportViewController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UITableView tblTimeReports { get; set; }

		void ReleaseDesignerOutlets ()
		{
			if (tblTimeReports != null) {
				tblTimeReports.Dispose ();
				tblTimeReports = null;
			}
		}
	}
}
